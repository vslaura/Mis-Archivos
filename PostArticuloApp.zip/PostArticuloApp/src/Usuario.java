
public class Usuario {
	
	RedSocial redSocial;
	
	public void post(Articulo articulo){
		redSocial.post(articulo);
	}

	public void setRedSocial(RedSocial redSocial) {
		this.redSocial = redSocial;
	}

	
	
}
