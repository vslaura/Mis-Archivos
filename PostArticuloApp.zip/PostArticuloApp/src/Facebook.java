
public class Facebook implements RedSocial{

	public void post(Articulo articulo) {
		System.out.println("posteando con facebook.. lero lero");
	}

}
