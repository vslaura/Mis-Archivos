
public interface RedSocial {

	public void post(Articulo articulo);
	
}
