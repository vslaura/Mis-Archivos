
public class Articulo {

}
